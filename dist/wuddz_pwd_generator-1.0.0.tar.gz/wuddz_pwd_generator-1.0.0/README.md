<h1 align="center">Wuddz Password Generator</h1>

## Description
 - A Simple Script That Prints A Generated Password To Console, Based On Specified Criteria
 
 - Long Story Short Currently Working On A Project, Needed Some Randomly Generated Strings, Since I Don't Do Anything Half-Assed Wrote This Script.

## Prerequisites
 - Python : 3.6

## Installation
Install using [PyPI](https://pypi.org/project/wuddz-pwd-generator):
```
$ pip install wuddz-pwd-generator
```
Install locally by cloning or downloading and extracting the repo, then cd into 'dist' directory and execute:
```
$ pip install wuddz_pwd_generator-1.0.0.tar.gz
```
Then to run it, execute the following in the terminal:
```
$ wudz-pwd
```

### Usage
Print 24 character password consisting of upper & lowercase letters and digits (default password type):
```
$ wudz-pwd 24
```
Print 24 character password consisting of upper & lower case letters, digits and special characters:
```
$ wudz-pwd 24 lds
```

## Contact Info:
 - Email:     wuddz_devs@protonmail.com                                                              
 - Github:    https://github.com/wuddz-devs                                                          
 - Telegram:  https://t.me/wuddz_devs
 - Youtube:   https://youtube.com/@wuddz-devs
 - Reddit:    https://reddit.com/user/wuddz-devs

### Buy Me A Coffee!!
 - ERC20 Address: 0x1F1C47dD653Af628D394eac7bAA9Ccf774fd784f

#### Peace & Love Always!!
